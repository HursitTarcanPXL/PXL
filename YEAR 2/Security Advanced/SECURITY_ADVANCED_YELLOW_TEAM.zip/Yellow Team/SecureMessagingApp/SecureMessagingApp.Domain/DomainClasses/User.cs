﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SecureMessagingApp.Domain.SecureClasses;

namespace SecureMessagingApp.Domain.DomainClasses
{
    public class User
    {
        public User()
        {
            EncryptedPackets = new List<EncryptedPacket>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public byte[] PasswordHash { get; set; }

        public byte[] Salt { get; set; }

        public List<EncryptedPacket> EncryptedPackets { get; set; }

        public string PublicRsaKeyPath { get; set; }

        public string PrivateRsaKeyPath { get; set; }

        public string PublicSignatureKeyPath { get; set; }

        public string PrivateSignatureKeyPath { get; set; }
    }
}
