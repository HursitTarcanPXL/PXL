﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SecureMessagingApp.Domain.SecureClasses
{
    public class HybridEncryption
    {
        private readonly AesEncryption _aes = new AesEncryption();
        private readonly RsaWithXmlKey _rsa = new RsaWithXmlKey();
        private readonly DigitalSignature _signature = new DigitalSignature();

        public EncryptedPacket EncryptData(byte[] original, string publicRsaKeyPath, string privateSignatureKeyPath)
        {
            //Generate aes key
            var sessionKey = _aes.GenerateRandomNumber(32);
            //Create packet and set iv
            var encryptedPacket = new EncryptedPacket() { Iv = _aes.GenerateRandomNumber(16) };
            //Encrypt data with aes
            encryptedPacket.EncryptedData = _aes.Encrypt(original, sessionKey, encryptedPacket.Iv);
            //Encrypt session key with rsa
            encryptedPacket.EncryptedSessionKey = _rsa.EncryptData(publicRsaKeyPath, sessionKey);
            //Add hmac for integrity check
            using (var hmac = new HMACSHA256(sessionKey))
            {
                encryptedPacket.Hmac = hmac.ComputeHash(encryptedPacket.EncryptedData);
            }
            //Sign with signature
            encryptedPacket.Signature = _signature.SignData(encryptedPacket.Hmac, privateSignatureKeyPath);

            return encryptedPacket;
        }
        public byte[] DecryptData(EncryptedPacket packet, string privateRsaKeyPath,string publicSignatureKeyPath)
        {
            //Decrypt aes key with rsa
            var decryptedSessionKey = _rsa.DecryptData(privateRsaKeyPath, packet.EncryptedSessionKey);
            //Recalculate HMAC and compare to HMAC in packet. Throw exception when these don't match          
            using (var hmac = new HMACSHA256(decryptedSessionKey))
            {
                var hmacToCheck = hmac.ComputeHash(packet.EncryptedData);

                if (!Compare(packet.Hmac, hmacToCheck))
                {
                    throw new CryptographicException("HMAC for decryption does not match encrypted packet.");
                }
                if (!_signature.VerifySignature(packet.Hmac, packet.Signature, publicSignatureKeyPath))
                {
                    throw new CryptographicException("Digital signature can not be verified.");
                }
            }
            //Decrypt data with aes using decrypted session key
            var decryptedData = _aes.Decrypt(packet.EncryptedData, decryptedSessionKey, packet.Iv);

            return decryptedData;
        }
        private static bool Compare(byte[] array1, byte[] array2)
        {
            var result = array1.Length == array2.Length;

            for (var i = 0; i < array1.Length && i < array2.Length; ++i)
            {
                result &= array1[i] == array2[i];
            }
            return result;
        }
    }
}
