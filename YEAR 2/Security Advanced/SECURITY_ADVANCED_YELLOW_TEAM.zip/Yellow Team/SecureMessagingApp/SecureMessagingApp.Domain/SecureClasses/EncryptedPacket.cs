﻿using SecureMessagingApp.Domain.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureMessagingApp.Domain.SecureClasses
{
    public class EncryptedPacket
    {
        public int Id { get; set; }

        public string Sender { get; set; }

        public byte[] EncryptedSessionKey { get; set; }

        public byte[] EncryptedData { get; set; }

        public byte[] Iv { get; set; }

        public byte[] Hmac { get; set; }

        public byte[] Signature { get; set; }

        public User User { get; set; }

        public int UserId { get; set; }

        public string DataType { get; set; }
        public string FileExt { get; set; }

    }
}
