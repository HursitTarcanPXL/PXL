﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureMessagingApp.Domain.Models
{
    public class FileViewModel
    {
        public byte[] File { get; set; }
        public string FileExt { get; set; }
        public string Sender { get; set; }
    }
}
