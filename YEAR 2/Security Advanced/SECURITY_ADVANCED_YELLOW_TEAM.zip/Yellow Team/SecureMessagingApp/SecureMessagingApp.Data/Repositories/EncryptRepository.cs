﻿using SecureMessagingApp.Domain.DomainClasses;
using SecureMessagingApp.Domain.Models;
using SecureMessagingApp.Domain.SecureClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureMessagingApp.Data.Repositories
{
    public class EncryptRepository
    {
        private CryptoContext _cryptoContext = new CryptoContext();
        private readonly HybridEncryption _hybridEncryption = new HybridEncryption();
        private UserRepository _userRepository = new UserRepository();

        public void SendEncryptedMessage(string message, User fromUser, User toUser)
        {
            EncryptedPacket sendPacket = _hybridEncryption.EncryptData(Encoding.UTF8.GetBytes(message), toUser.PublicRsaKeyPath, fromUser.PrivateSignatureKeyPath);

            sendPacket.Sender = fromUser.Name;
            sendPacket.UserId = toUser.Id;
            sendPacket.DataType = "message";
            sendPacket.FileExt = null;

            _cryptoContext.EncryptedPackets.Add(sendPacket);
            _cryptoContext.SaveChanges();
        }
        public void SendEncryptedFile(byte[] file, string fileExt, User fromUser, User toUser)
        {
            EncryptedPacket sendPacket = _hybridEncryption.EncryptData(file, toUser.PublicRsaKeyPath, fromUser.PrivateSignatureKeyPath);
            sendPacket.Sender = fromUser.Name;
            sendPacket.UserId = toUser.Id;
            sendPacket.DataType = "file";
            sendPacket.FileExt = fileExt;

            _cryptoContext.EncryptedPackets.Add(sendPacket);
            _cryptoContext.SaveChanges();
        }
        public List<string> RetrieveEncryptedMessages(User currentUser, List<User> otherUsers)
        {
            List<string> messages = new List<string>();

            List<EncryptedPacket> packets = GetEncryptedPackets(currentUser, "message");

            if (packets == null || packets.Count == 0)
            {
                return null;
            }

            byte[] messageData;
            string currentMessage;

            foreach (EncryptedPacket packet in packets)
            {
                var fromUser = otherUsers.FirstOrDefault(u => u.Name == packet.Sender);
                string privateRsaKeyPath = currentUser.PrivateRsaKeyPath;
                string publicSignatureKeyPath = fromUser.PublicSignatureKeyPath;

                messageData = _hybridEncryption.DecryptData(packet, privateRsaKeyPath, publicSignatureKeyPath);
                currentMessage = $"{fromUser.Name}:\t {Encoding.UTF8.GetString(messageData)}";

                messages.Add(currentMessage);
            }
            _cryptoContext.EncryptedPackets.RemoveRange(packets);
            _cryptoContext.SaveChanges();
            return messages;

        }
    
        public List<FileViewModel> RetrieveEncryptedFiles(User currentUser, List<User> otherUsers)
        {
            List<FileViewModel> files = new List<FileViewModel>();

            List<EncryptedPacket> packets = GetEncryptedPackets(currentUser, "file");

            if (packets == null || packets.Count == 0)
            {
                return null;
            }

            byte[] fileData;

            foreach(EncryptedPacket packet in packets)
            {
                var fromUser = otherUsers.FirstOrDefault(u => u.Name == packet.Sender);
                string privateRsaKeyPath = currentUser.PrivateRsaKeyPath;
                string publicSignatureKeyPath = fromUser.PublicSignatureKeyPath;

                fileData = _hybridEncryption.DecryptData(packet, privateRsaKeyPath, publicSignatureKeyPath);

                var fileViewModel = new FileViewModel { File = fileData, FileExt = packet.FileExt, Sender = fromUser.Name };
                files.Add(fileViewModel);
            }
            _cryptoContext.EncryptedPackets.RemoveRange(packets);
            _cryptoContext.SaveChanges();
            return files;
        }
        private List<EncryptedPacket> GetEncryptedPackets(User currentUser, string dataType)
        {
            var packets = _cryptoContext.EncryptedPackets.Where(p => p.UserId == currentUser.Id).Where(p => p.DataType == dataType).ToList();
            return packets;
        }
    }
}
