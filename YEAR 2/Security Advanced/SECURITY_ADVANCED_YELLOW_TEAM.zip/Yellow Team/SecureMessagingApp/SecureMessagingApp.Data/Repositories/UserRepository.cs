﻿using Microsoft.EntityFrameworkCore;
using SecureMessagingApp.Domain.DomainClasses;
using SecureMessagingApp.Domain.SecureClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureMessagingApp.Data.Repositories
{
    
    public class UserRepository
    {
        private CryptoContext _cryptoContext = new CryptoContext();
        public void CreateNewUserAndAddToDatabase(string name, string password)
        {
            byte[] salt = PasswordHasher.GenerateSalt();

            User newUser = new User()
            {
                Name = name,
                Salt = salt,
                PasswordHash = PasswordHasher.HashPasswordWithSalt(Encoding.UTF8.GetBytes(password), salt),
            };
            newUser.PublicRsaKeyPath = $".\\{newUser.Name}Keys\\RSA\\publickey.xml";
            newUser.PrivateRsaKeyPath = $".\\{newUser.Name}Keys\\RSA\\privatekey.xml";

            newUser.PublicSignatureKeyPath = $".\\{newUser.Name}Keys\\Signature\\publickey.xml";
            newUser.PrivateSignatureKeyPath = $".\\{newUser.Name}Keys\\Signature\\privatekey.xml";

            RsaWithXmlKey rsa = new RsaWithXmlKey();
            rsa.AssignNewKey(newUser.PublicRsaKeyPath, newUser.PrivateRsaKeyPath);

            DigitalSignature signature = new DigitalSignature();
            signature.AssignNewKey(newUser.PublicSignatureKeyPath, newUser.PrivateSignatureKeyPath);

            _cryptoContext.Users.Add(newUser);
            _cryptoContext.SaveChanges();
        }
        public List<User> GetAllUsersWithMessages()
        {
            return _cryptoContext.Users.Include(u => u.EncryptedPackets).ToList();
        }
        public User GetUserByName(string name)
        {
            return _cryptoContext.Users.FirstOrDefault(u => u.Name == name);
        }
        public bool NameExists(string name)
        {
            List<User> _allUsers = _cryptoContext.Users.ToList();
            bool isValid = false;
            if (_allUsers.Count == 0)
            {
                return isValid;
            }
            else
            {
                for (int i = 0; i < _allUsers.Count; i++)
                {
                    if (_allUsers[i].Name == name)
                    {
                        isValid = true;
                    }
                }
            }
            return isValid;
        }
        public bool PasswordIsValid(User user, string password)
        {
            bool isValid = false;
            
            byte[] calculatedPasswordHash = PasswordHasher.HashPasswordWithSalt(Encoding.UTF8.GetBytes(password), user.Salt);

            if (PasswordHasher.Compare(calculatedPasswordHash, user.PasswordHash))
            {
                isValid = true;
            }
            return isValid;
        }
    }
}
