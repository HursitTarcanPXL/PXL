﻿using Microsoft.EntityFrameworkCore;
using SecureMessagingApp.Domain.DomainClasses;
using SecureMessagingApp.Domain.SecureClasses;

namespace SecureMessagingApp.Data
{
    public class CryptoContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public DbSet<EncryptedPacket> EncryptedPackets { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Data Source=(localdb)\\mssqllocaldb;Initial Catalog=CryptoDB;Integrated Security=True;";
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}
