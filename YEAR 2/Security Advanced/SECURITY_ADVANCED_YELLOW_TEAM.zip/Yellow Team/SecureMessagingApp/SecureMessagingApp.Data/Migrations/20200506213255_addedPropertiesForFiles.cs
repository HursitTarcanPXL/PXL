﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SecureMessagingApp.Data.Migrations
{
    public partial class addedPropertiesForFiles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DataType",
                table: "EncryptedPackets",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FileExt",
                table: "EncryptedPackets",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DataType",
                table: "EncryptedPackets");

            migrationBuilder.DropColumn(
                name: "FileExt",
                table: "EncryptedPackets");
        }
    }
}
