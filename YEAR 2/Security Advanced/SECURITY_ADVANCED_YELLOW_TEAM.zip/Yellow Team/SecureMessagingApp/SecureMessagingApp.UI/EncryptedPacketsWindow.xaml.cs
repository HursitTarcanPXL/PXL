﻿using Microsoft.Win32;
using SecureMessagingApp.Data.Repositories;
using SecureMessagingApp.Domain.DomainClasses;
using SecureMessagingApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace SecureMessagingApp.UI
{
    /// <summary>
    /// Interaction logic for EncryptedPacketsWindow.xaml
    /// </summary>
    public partial class EncryptedPacketsWindow : Window
    {
        private UserRepository _userRepository;
        private User _currentUser;
        private List<User> _allUsers;
        private List<User> _allOtherUsers;
        private EncryptRepository _encryptRepository = new EncryptRepository();
        private List<FileViewModel> _loadedFiles = new List<FileViewModel>();
        private FileViewModel _currentFile = new FileViewModel();
        private int _counter = 0;
        public EncryptedPacketsWindow(UserRepository userRepository, User currentUser, List<User> allUsers)
        {
            InitializeComponent();
            _userRepository = userRepository;
            _currentUser = currentUser;
            _allUsers = allUsers;

            //Create other list with users except current user
            _allOtherUsers = new List<User>(_allUsers);
            _allOtherUsers.Remove(_currentUser);

            ViewIncomingMessages();
            LoadFiles();
        }

        //Get al messages for current user and show them in a textbox
        private void ViewIncomingMessages()
        {
            List<string> incomingMessages = _encryptRepository.RetrieveEncryptedMessages(_currentUser, _allOtherUsers);
            if (incomingMessages != null)
            {
                incomingMessages.ForEach(u =>
                {
                    ReceivedMessagesTextBox.AppendText(u);
                    ReceivedMessagesTextBox.AppendText(Environment.NewLine);
                });
            }
            
        }
        private void LoadFiles()
        {
            _loadedFiles = _encryptRepository.RetrieveEncryptedFiles(_currentUser, _allOtherUsers);
            if (_loadedFiles != null)
            {
                _currentFile = _loadedFiles[_counter];
                FileTextBlock.Text = $"You received a file from: {_currentFile.Sender}";
                SaveFileButton.Visibility = Visibility.Visible;
            }
        }

        private void SendMessageOrFileButton_Click(object sender, RoutedEventArgs e)
        {
            var window = new SendEncryptedPacketsWindow(_currentUser, _allOtherUsers);
            Close();
            window.ShowDialog();
        }

        private void SignOutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            Close();
            window.ShowDialog();
        }

        private void SaveFileButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            dialog.DefaultExt = _currentFile.FileExt;

            if (dialog.ShowDialog() == true)
            {
                string currentFilePath = dialog.FileName;
                File.WriteAllBytes(currentFilePath, _currentFile.File);
            }

            _counter++;
            if (_counter < _loadedFiles.Count)
            {
                _currentFile = _loadedFiles[_counter];
                FileTextBlock.Text = $"You received a file from: {_currentFile.Sender}";
            }
            else
            {
                _currentFile = null;
                FileTextBlock.Text = "No files received";
                SaveFileButton.Visibility = Visibility.Hidden;
            }

        }
    }
}
