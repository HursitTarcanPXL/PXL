﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SecureMessagingApp.Data;
using SecureMessagingApp.Data.Repositories;
using SecureMessagingApp.Domain.DomainClasses;
using SecureMessagingApp.Domain.SecureClasses;

namespace SecureMessagingApp.UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
   
    public partial class MainWindow : Window
    {
        private List<User> _allUsers = new List<User>();
        private User _loggedInUser = new User();
        private UserRepository _userRepository = new UserRepository();

        public MainWindow()
        {
            InitializeComponent();
            _allUsers = _userRepository.GetAllUsersWithMessages();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            //Close current window and open registration window
            ErrorTextBlock.Text = string.Empty;

            RegistrationWindow registrationWindow = new RegistrationWindow(_userRepository);
            Close();
            registrationWindow.ShowDialog();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            
            if (IsInputValid())
            {
                //Close current window and open messages window if login is succesfull
                ErrorTextBlock.Text = string.Empty;
                EncryptedPacketsWindow encryptedPacketsWindow = new EncryptedPacketsWindow(_userRepository, _loggedInUser, _allUsers);
                Close();
                encryptedPacketsWindow.ShowDialog();
            }
        }

        private bool IsInputValid()
        {
            //Check if values are filled in both of the textboxes
            bool inputIsValid = false;

            ErrorTextBlock.Text = string.Empty;
            string name = NameTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(name))
            {
                ErrorTextBlock.Text = "No name was filled in, please fill in a valid name.";
            }
            else
            {
                if (string.IsNullOrEmpty(password))
                {
                    ErrorTextBlock.Text = "No password was filled in, please fill in a valid password.";
                }
                else
                {
                    //Check if the name entered exists in the database (= account exists)
                    bool userNameIsValid = false;
                    userNameIsValid = _userRepository.NameExists(name);

                    if (userNameIsValid)
                    {
                        //Check if the valid user has entered the right password
                        bool passwordIsValid = false;
                        _loggedInUser = _userRepository.GetUserByName(name);
                        passwordIsValid = _userRepository.PasswordIsValid(_loggedInUser, password);

                        if (passwordIsValid)
                        {
                            inputIsValid = true;
                        }
                        else
                        {
                            ErrorTextBlock.Text = "You entered the wrong password";
                        }
                    }
                    else
                    {
                        ErrorTextBlock.Text = "The name you entered is not valid.";
                    }
                }
            }
            return inputIsValid;
        }

        
    }
}
