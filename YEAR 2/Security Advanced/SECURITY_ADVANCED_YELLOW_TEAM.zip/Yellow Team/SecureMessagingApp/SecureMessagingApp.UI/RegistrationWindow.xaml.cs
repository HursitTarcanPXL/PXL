﻿using SecureMessagingApp.Data.Repositories;
using SecureMessagingApp.Domain.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SecureMessagingApp.UI
{
    /// <summary>
    /// Interaction logic for RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        
        private UserRepository _userRepository;
        public RegistrationWindow(UserRepository userRepository)
        {
            InitializeComponent();         
            _userRepository = userRepository;
        }

        private void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            if (IsInputValid())
            {
                //Add the valid user to the database
                _userRepository.CreateNewUserAndAddToDatabase(NameTextBox.Text, PasswordBox.Password);
                              
                //Close current window and open the log in window
                MainWindow authenticationWindow = new MainWindow();
                this.Close();
                authenticationWindow.ShowDialog();
            }
        }
        private bool IsInputValid()
        {
            //Check if a value has been filled in both of the textboxes
            bool isValid = false;

            string name = NameTextBox.Text;
            string password = PasswordBox.Password;

            if (name == null || name == string.Empty)
            {
                ErrorTextBlock.Text = "No name was filled in, please fill in a valid name.";
            }
            else if (password == null || password == string.Empty)
            {
                ErrorTextBlock.Text = "No password was filled in, please fill in a valid password.";
            }
            else
            {
                //Check if the name the user wrote in the textbox is unique
                bool userNameExists = false;
                userNameExists = _userRepository.NameExists(name);
                if (!userNameExists)
                {
                    isValid = true;
                    MessageBox.Show($"Account with name {NameTextBox.Text} created succesfully.");
                    ErrorTextBlock.Text = string.Empty;
                }
                else
                {
                    ErrorTextBlock.Text = $"Can't create account with name: {name} because it already exists";
                }
            }
            return isValid;
        }
    }
}
