﻿using Microsoft.Win32;
using SecureMessagingApp.Data.Repositories;
using SecureMessagingApp.Domain.DomainClasses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SecureMessagingApp.UI
{
    /// <summary>
    /// Interaction logic for SendEncryptedPacketsWindow.xaml
    /// </summary>
    public partial class SendEncryptedPacketsWindow : Window
    {
        private EncryptRepository _encryptRepository = new EncryptRepository();
        private User _currentUser;
        private List<User> _allOtherUsers;
        private byte[] _currentFile = null;
        private string _currentFileExtension = string.Empty;
        public SendEncryptedPacketsWindow(User currentUser, List<User> allOtherUsers)
        {
            InitializeComponent();

            _currentUser = currentUser;
            _allOtherUsers = allOtherUsers;

            UsersMessageComboBox.ItemsSource = _allOtherUsers;
            UsersFileComboBox.ItemsSource = _allOtherUsers;
        }

        private void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {
            //Check if a recipient is selected
            var userToSendMessage = (User)UsersMessageComboBox.SelectedItem;
            if (userToSendMessage != null)
            {
                //Check if a message has been entered
                string message = SendMessageTextBox.Text;
                if (!string.IsNullOrEmpty(message))
                {
                    //Message is valid: message gets encrypted and stored in database
                    ErrorTextBlock.Text = string.Empty;
                    UsersMessageComboBox.SelectedItem = null;
                    SendMessageTextBox.Text = string.Empty;

                    _encryptRepository.SendEncryptedMessage(message, _currentUser, userToSendMessage);
                    MessageBox.Show($"Message was succesfully sent to {userToSendMessage.Name}");
                }
                else
                {
                    ErrorTextBlock.Text = "Please enter a message before trying to send it.";
                }
            }
            else
            {
                ErrorTextBlock.Text = "Please specify the recipient before sending a message.";
            }
        }

        private void ChooseFileButton_Click(object sender, RoutedEventArgs e)
        {
            //This lets the user open a file they wish to send and store the file (byte[]) + extension for further use
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (dialog.ShowDialog() == true)
            {
                string currentFilePath = dialog.FileName;
                _currentFileExtension = System.IO.Path.GetExtension(currentFilePath);
                _currentFile = File.ReadAllBytes(currentFilePath);
            }
            //Show output to user
            MessageBox.Show("File selected.");
            ChooseFileButton.Content = "Choose other file";
        }
        private void SendFileButton_Click(object sender, RoutedEventArgs e)
        {
            //Check if a recipient has been selected
            var userToSendFile = (User)UsersFileComboBox.SelectedItem;
            if (userToSendFile != null)
            {
                //Check if the sender has selected a file
                if (_currentFile != null && !string.IsNullOrEmpty(_currentFileExtension))
                {
                    //File is valid; File gets encrypted and stored in the database
                    FileErrorTextBlock.Text = string.Empty;
                    UsersFileComboBox.SelectedItem = null;

                    _encryptRepository.SendEncryptedFile(_currentFile, _currentFileExtension, _currentUser, userToSendFile);
                    _currentFile = null;
                    _currentFileExtension = null;
                    MessageBox.Show($"File was succesfully sent to {userToSendFile.Name}");
                }
                else
                {
                    FileErrorTextBlock.Text = "Please select a file before sending a file.";
                }
            }
            else
            {
                FileErrorTextBlock.Text = "Please specify the recipient before sending a file.";
            }
        }

        private void SignOutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            Close();
            window.ShowDialog();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            var allUsers = _allOtherUsers;
            allUsers.Add(_currentUser);

            EncryptedPacketsWindow window = new EncryptedPacketsWindow(new UserRepository(), _currentUser, allUsers);
            Close();
            window.ShowDialog();
        }

   
    }
}
