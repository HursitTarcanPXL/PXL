﻿using System.Collections.Generic;

namespace WPF_Databinding_Presidents
{
    internal class PresidentList : List<President> { }
}
