﻿using System;

namespace WPF_Databinding_Presidents
{
    internal class President
    {
        public Uri ImageUri { get; set; }
        public string Name { get; set; }
    }
}
