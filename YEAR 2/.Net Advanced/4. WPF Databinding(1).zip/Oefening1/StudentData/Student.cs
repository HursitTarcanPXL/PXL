﻿namespace StudentData
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public int ZipCode { get; set; }
        public string Phone { get; set; }
        public string Cell { get; set; }
    }
}
