﻿namespace StudentData
{
    public class State
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
