﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace EscapeRoom
{
    public class Wall : GamePiece
    {
        public Wall(Canvas canvas, int row = 0, int column = 0) : base(canvas, row, column)
        {
        }

        public override bool CanAcceptPlayer()
        {
            return false; 
        }

        protected override Shape CreateVisual(double x, double y)
        {
            Rectangle rectangle = new Rectangle()
            {
                Width = GameConstants.SquareWidth,
                Height = GameConstants.SquareWidth,
                Margin = new Thickness(x, y, 0, 0),
                Stroke = GameConstants.WallBrush
            };
            return rectangle;
        }
    }
}
