﻿using System;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace EscapeRoom
{
    public enum PlayerState
    {
        Alive,
        Winner,
        LoserExhausted, // no more steps left
        LoserHole // fallen into a hole
    }

    public class Player
    {
        private Player _player; 
        private int _remainingSteps;

        private Image _image;
        private BitmapImage _aliveImage;
        private BitmapImage _loserImage;
        private BitmapImage _winnerImage;

        public Player(int steps = GameConstants.MaxSteps)
        {
            State = PlayerState.Alive;
            _remainingSteps = steps;

            _image = new Image()
            {
                Width = GameConstants.SquareWidth - 2 * GameConstants.Gap,
                Height = GameConstants.SquareWidth - 2 * GameConstants.Gap,
                Stretch = Stretch.Uniform
            };

            _aliveImage = CreateBitmapImage(@"/images/alive.png");
            _loserImage = CreateBitmapImage(@"/images/loser.png");
            _winnerImage = CreateBitmapImage(@"/images/winner.png");
            UpdateImageSourceBasedOnState();
        }

        public void Move(GamePiece fromPiece, GamePiece toPiece)
        {
            //TODO: implement this method

            // remove this player from the "fromPiece"
            // add this player to the "toPiece"
            // decrease remaining steps and update State and Image accordingly

            fromPiece.RemovePlayer(_player);
            toPiece.AcceptPlayer(_player);
            _remainingSteps -= 1; 

            if (_remainingSteps == 0)
            {
                State = PlayerState.LoserExhausted;
            }
            else
            {
                State = PlayerState.Alive; 
            }

            UpdateImageSourceBasedOnState();
        }

        public Image Image => _image;

        public PlayerState State { get; set; }

        private void UpdateImageSourceBasedOnState()
        {
            // TODO: set the right image based on the current state.

            if (State == PlayerState.Alive)
            {
                _image.Source = _aliveImage; 
            }
            else if (State == PlayerState.LoserHole || State == PlayerState.LoserExhausted)
            {
                _image.Source = _loserImage;
            }
            else
            {
                _image.Source = _winnerImage; 
            }
        }

        public int RemainingSteps => _remainingSteps;

        private BitmapImage CreateBitmapImage(string relativeFilePath)
        {
            var bitmapImage = new BitmapImage();
            bitmapImage.BeginInit();
            bitmapImage.UriSource = new Uri(relativeFilePath, UriKind.Relative);
            bitmapImage.EndInit();
            return bitmapImage;
        }
    }
}