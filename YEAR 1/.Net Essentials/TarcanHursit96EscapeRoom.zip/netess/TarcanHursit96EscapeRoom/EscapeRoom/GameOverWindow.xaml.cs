﻿using System.Windows;

namespace EscapeRoom
{
    /// <summary>
    /// Interaction logic for GameOverWindow.xaml
    /// </summary>
    public partial class GameOverWindow : Window
    {
        public GameOverWindow(Player player, string message)
        {
            InitializeComponent();
            // TODO, but KEEP this ctor signature!
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
