﻿using System;
using System.IO;
using System.Windows;

namespace EscapeRoom
{
    public partial class MainWindow : Window
    {
        private GameBuilder _gameBuilder; 
        private GamePiece[,] _board;
        private Player _player;
        private int _currentRow = 0;
        private int _currentColumn = 0;

        private Random _random; 
        
        public MainWindow()
        {
            InitializeComponent(); 
        }

        private void MovePlayerToNewPosition(int newRow, int newColumn)
        {
            // TODO
            // if newRow/newColumn are correct and reachable values, do the following:
            // - move the player from the current position to the new position
            // - update the progressbar to reflect the remaining steps
            // - check the outcome of the game
            // - if the game has ended, open an instance of GameOverWindow and show the
            //   player image and a message.

            try
            {
                //_player.Move(currentPosition, newPosition);
                stepsProgressBar.Value = _player.RemainingSteps;

                if (_player.State == PlayerState.LoserExhausted || _player.State == PlayerState.LoserHole || _player.State == PlayerState.Winner)
                {
                    GameOverWindow gameOverWindow = new GameOverWindow(_player, "Game Over");
                    gameOverWindow.Show();
                    gameOverWindow.Closing += GameOverWindow_Closing;
                    WindowState = WindowState.Minimized;
                }
            }
            catch (GameException ex)
            {
                MessageBox.Show(ex.Message); 
            }
            
        }

        private void GameOverWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            WindowState = WindowState.Normal; 
        }

        private void startItem_Click(object sender, RoutedEventArgs e)
        {
            //TODO

            // create a GameBuilder to read the config file from the desktop
            // and set the _board and _player members
            // use RandomizeStartPosition to set the start position
            // enable the buttons using a method from this class
            try
            {
                _gameBuilder = new GameBuilder("escaperoom.config", boardCanvas);

                _board = _gameBuilder.Board;
                _player = _gameBuilder.Player;
                RandomizeStartPosition();
                SetIsEnabledPropertyOnButtons(true);
            }
            catch (GameException ex)
            {
                MessageBox.Show(ex.Message); 
            }
        }

        private void SetIsEnabledPropertyOnButtons(bool value)
        {
            downButton.IsEnabled = value;
            upButton.IsEnabled = value;
            leftButton.IsEnabled = value;
            rightButton.IsEnabled = value;
        }

        private void RandomizeStartPosition()
        {
            try
            {
                _random = new Random(_board.Length);
                //Hier moet je de player zijn beginpositie gelijkstellen aan de gegenereerde Random waarde...
                // TODO: choose a valid start position (random) for the player on the board
            }
            catch (GameException ex)
            {
                MessageBox.Show(ex.Message); 
            }
        }

        private void exitItem_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
