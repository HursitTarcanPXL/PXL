﻿using System.Windows.Media;

namespace EscapeRoom
{
    public static class GameConstants
    {
        public const int BoardDimension = 9;
        public const int MaxSteps = 10;

        public const double SquareWidth = 55;
        public const double Gap = 5;
        public const double StrokeThickness = 3;
        
        public static Brush CellBorderBrush = Brushes.Black;
        public static Brush HoleBrush = Brushes.Black;
        public static Brush DoorBrush = Brushes.LightGreen;
        public static Brush WallBrush = Brushes.DarkGray;
    }
}
