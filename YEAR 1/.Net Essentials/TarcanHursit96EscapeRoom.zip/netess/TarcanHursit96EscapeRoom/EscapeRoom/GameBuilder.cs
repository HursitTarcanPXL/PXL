﻿using System;
using System.IO;
using System.Windows.Controls;

namespace EscapeRoom
{
    public class GameBuilder
    {
        private GamePiece[,] _board;
        private Player _player;

        public GameBuilder(string boardConfig, Canvas canvas)
        {
            _board = new GamePiece[GameConstants.BoardDimension, GameConstants.BoardDimension];
            canvas.Children.Clear();
            // TODO

            // read the boardConfig an create the _player and _board objects
            // raise exceptions when appropriate:
            //     - config file not on the desktop
            //     - a board line contains not enough chars
            //     - a board line contains an illegal char

            string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = System.IO.Path.Combine(folderPath, boardConfig);
            
            StreamReader reader = File.OpenText(filePath);
            if (reader.ReadLine() == null)
            {
                throw new GameException("File Not Found Or File Empty! Please Check If File Is On Desktop!"); 
            }

            string playerAmountOfSteps = reader.ReadLine();

            _player = new Player(Convert.ToInt32(playerAmountOfSteps));

            string boardRow = reader.ReadLine(); 
            while (boardRow != null)
            {
                for (int row = 0; row < _board.Length; row++)
                {
                    for (int column = 0; column < boardRow.Length; column++)
                    {
                        if (boardRow.Length != GameConstants.BoardDimension)
                        {
                            throw new GameException("Error! Board Line Does Not Contain Enough Chars! Please Try Again!"); 
                        }
                        else
                        {
                            if (boardRow[column] == 'C')
                            {
                                _board[row, column] = new Cell(canvas, row, column);
                            }
                            else if (boardRow[column] == 'D')
                            {
                                _board[row, column] = new Door(canvas, row, column);
                            }
                            else if (boardRow[column] == 'W')
                            {
                                _board[row, column] = new Wall(canvas, row, column);
                            }
                            else if (boardRow[column] == 'H')
                            {
                                _board[row, column] = new Hole(canvas, row, column);
                            }
                            else
                            {
                                throw new GameException("Error! Line Has Illegal Char! Please Try Again!"); 
                            }
                        }
                    }
                }
                boardRow = reader.ReadLine(); 
            }

            for (int boardObject = 0; boardObject < _board.Length; boardObject++)
            {
                //canvas.Children.Add(_board.); 
                //De objecten in de tweedimensionale _board array moeten ook toegevoegd worden aan het canvas. Maar ik krijg dit niet tegoei. 
            }

        }

        public GamePiece[,] Board
        { 
            get => _board; 
            private set => _board = value;
        }

        public Player Player
        {
            get => _player;
            private set => _player = value;
        }

    }
}
