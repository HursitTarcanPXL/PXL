﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace EscapeRoom
{
    public class Hole : GamePiece
    {
        public Hole(Canvas canvas, int row = 0, int column = 0) : base(canvas, row, column)
        {
        }

        public override bool CanAcceptPlayer()
        {
            return true; 
            //Speler kan in een 'Hole' vallen.  
        }

        protected override Shape CreateVisual(double x, double y)
        {
            Rectangle rectangle = new Rectangle()
            {
                Width = GameConstants.SquareWidth,
                Height = GameConstants.SquareWidth,
                Margin = new Thickness(x, y, 0, 0),
                Stroke = GameConstants.HoleBrush
            };
            return rectangle;
        }

        public override void AcceptPlayer(Player player)
        {
            player.State = PlayerState.LoserHole;
        }
    }
}
