﻿using System.Windows;

namespace EscapeRoom
{
    /// <summary>
    /// Interaction logic for GameOverWindow.xaml
    /// </summary>
    public partial class GameOverWindow : Window
    {
        public GameOverWindow(Player player, string message)
        {
            InitializeComponent();
            playerImage = player.Image;
            messageTextBlock.Text = message;
            // TODO, but KEEP this ctor signature!
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow mainWindow = new MainWindow();
        }
    }
}
