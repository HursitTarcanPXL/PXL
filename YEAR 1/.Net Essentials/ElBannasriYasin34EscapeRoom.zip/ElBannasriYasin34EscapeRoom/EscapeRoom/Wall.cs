﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace EscapeRoom
{
    class Wall : GamePiece
    {
        public Wall(Canvas canvas, int row = 0, int column = 0) : base(canvas, row, column)
        {
        }

        public override bool CanAcceptPlayer()
        {
            return false;
        }

        public override Shape CreateVisual(double x, double y)
        {
            return base.CreateVisual(x, y);
        }

    }
}
