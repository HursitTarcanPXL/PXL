﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace EscapeRoom
{
    public class GameBuilder
    {
        private GamePiece[,] _board;
        private Player _player;

        public GameBuilder(string boardConfig, Canvas canvas)
        {
            _board = new GamePiece[GameConstants.BoardDimension, GameConstants.BoardDimension];
            canvas.Children.Clear();
            // TODO
            MessageBox.Show(boardConfig);
            StreamReader streamReader = new StreamReader(boardConfig);
            List<string> boardLines = new List<string>();
            boardLines = File.ReadAllLines(boardConfig).ToList();
            for (int row = 1; row < 10; row++)
            {
                List<string> currentSplitLine = boardLines[row].Split().ToList();
                for (int column = 0; column < 9; column++)
                {
                    if (boardLines[row][column] == 'C')
                    {
                        _board[row - 1, column] = new Cell(canvas, row - 1, column);
                        canvas.Children.Add(_board[row - 1, column].CreateVisual(row - 1, column));
                    }
                    else if (boardLines[row][column] == 'W')
                    {
                        _board[row - 1, column] = new Wall(canvas, row - 1, column);
                        canvas.Children.Add(_board[row - 1, column].CreateVisual(row - 1, column));

                    }
                    else if (boardLines[row][column] == 'D')
                    {
                        _board[row - 1, column] = new Door(canvas, row - 1, column);
                        canvas.Children.Add(_board[row - 1, column].CreateVisual(row - 1, column));

                    }
                    else if (boardLines[row][column] == 'H')
                    {
                        _board[row - 1, column] = new Hole(canvas, row - 1, column);
                        canvas.Children.Add(_board[row - 1, column].CreateVisual(row - 1, column));

                    }
                    else
                    {
                        throw new GameException();
                    }
                }
            }
            _player = new Player(Convert.ToInt32(boardLines[0]));
            // read the boardConfig an create the _player and _board objects
            // raise exceptions when appropriate:
            //     - config file not on the desktop
            //     - a board line contains not enough chars
            //     - a board line contains an illegal char
        }

        public GamePiece[,] Board
        { 
            get => _board; 
            private set => _board = value;
        }

        public Player Player
        {
            get => _player;
            private set => _player = value;
        }

    }
}
