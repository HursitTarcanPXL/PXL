﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;

namespace EscapeRoom
{
    public partial class MainWindow : Window
    {
        private GamePiece[,] _board;
        private Player _player;
        private int _currentRow = 0;
        private int _currentColumn = 0;
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MovePlayerToNewPosition(int newRow, int newColumn)
        {
            // TODO
            try
            {
                if (_player.State != PlayerState.LoserExhausted || _player.State != PlayerState.LoserHole)
                {
                    _player.Move(_board[_currentRow, _currentColumn], _board[newRow, newColumn]);

                }
                else
                {
                    string message;
                    if (_player.State == PlayerState.Winner)
                    {
                        message = "You have won";
                        GameOverWindow gameOverWindow = new GameOverWindow(_player, message);
                        this.Hide();
                        gameOverWindow.Show();
                    }
                    else if (_player.State == PlayerState.LoserExhausted)
                    {
                        message = "You have run out of moves";
                        GameOverWindow gameOverWindow = new GameOverWindow(_player, message);
                        this.Hide();
                        gameOverWindow.Show();
                    }
                    else if (_player.State == PlayerState.LoserHole)
                    {
                        message = "You fell in a hole";
                        GameOverWindow gameOverWindow = new GameOverWindow(_player, message);
                        this.Hide();
                        gameOverWindow.Show();
                    }

                }
            }
            catch (GameException)
            {
                MessageBox.Show("Error in moving to new position");
            }
            // if newRow/newColumn are correct and reachable values, do the following:
            // - move the player from the current position to the new position
            // - update the progressbar to reflect the remaining steps
            // - check the outcome of the game
            // - if the game has ended, open an instance of GameOverWindow and show the
            //   player image and a message.
        }

        private void startItem_Click(object sender, RoutedEventArgs e)
        {
            //TODO
            OpenFileDialog openFileDialog = new OpenFileDialog();
            string startFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            openFileDialog.InitialDirectory = startFolder;

            try
            {
                if (openFileDialog.ShowDialog() == true)
                {
                    string fileName = openFileDialog.FileName;
                    GameBuilder gameBuilder = new GameBuilder(fileName, boardCanvas);
                    _board = gameBuilder.Board;
                    _player = gameBuilder.Player;
                    stepsProgressBar.Value = _player.RemainingSteps;
                }


            }
            catch (GameException)
            {
                MessageBox.Show("Error");
            }

            SetIsEnabledPropertyOnButtons(true);
            // create a GameBuilder to read the config file from the desktop
            // and set the _board and _player members
            // use RandomizeStartPosition to set the start position
            // enable the buttons using a method from this class
        }

        private void SetIsEnabledPropertyOnButtons(bool value)
        {
            downButton.IsEnabled = value;
            upButton.IsEnabled = value;
            leftButton.IsEnabled = value;
            rightButton.IsEnabled = value;
        }

        private void RandomizeStartPosition()
        {
            Random randomGetal = new Random();
            int randomRow = randomGetal.Next(0, 10);
            int randomColumn = randomGetal.Next(0, 10);
            
        }

        private void exitItem_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
