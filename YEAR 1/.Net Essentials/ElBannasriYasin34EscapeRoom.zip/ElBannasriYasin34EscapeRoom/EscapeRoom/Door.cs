﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace EscapeRoom
{
    class Door : GamePiece
    {
        public Door(Canvas canvas, int row = 0, int column = 0) : base(canvas, row, column)
        {
        }

        public override bool CanAcceptPlayer()
        {
            return true;
        }

        public override void AcceptPlayer(Player player)
        {
            player.State = PlayerState.Alive;
        }

        public override Shape CreateVisual(double x, double y)
        {
            return base.CreateVisual(x, y);
        }
    }
}
