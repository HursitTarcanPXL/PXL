﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace EscapeRoom
{
    public abstract class GamePiece
    {
        // a GamePiece could contain a player object
        private Player _player;
        
        // shape represented by this gamepiece
        protected Shape _shape;

        // the canvas to put this gamepiece on
        protected Canvas _canvas;

        // topleft coordinates of this gamepiece on the canvas
        protected double _topX;
        protected double _topY;

        public GamePiece(Canvas canvas, int row = 0, int column = 0)
        {
            _canvas = canvas;
            //TODO: use ConvertRowAndColumnToXY to calculate proper _topX and _topY
            ConvertRowAndColumnToXY(row, column, out _topX, out _topY);
            _shape = CreateVisual(_topX, _topY);
            _canvas.Children.Add(_shape);
        }

        public void RemovePlayer(Player player)
        {
            _canvas.Children.Remove(player.Image);
            _player = null;
        }

        public abstract bool CanAcceptPlayer();

        public virtual void AcceptPlayer(Player player)
        {
            _player = player;
            _player.Image.Margin = new Thickness(_topX + GameConstants.Gap, _topY + GameConstants.Gap, 0, 0);
            _canvas.Children.Add(_player.Image);
        }

        public virtual Shape CreateVisual(double x, double y)
        {
            Rectangle rectangle = new Rectangle()
            {
                Width = GameConstants.SquareWidth,
                Height = GameConstants.SquareWidth,
                Margin = new Thickness(x, y, 0, 0)

            };
            return rectangle;
        }

        private void ConvertRowAndColumnToXY(int row, int column, out double x, out double y)
        {
            y = row * GameConstants.SquareWidth + (row + 1) * GameConstants.Gap;
            x = column * GameConstants.SquareWidth + (column + 1) * GameConstants.Gap;
        }
    }
}
