function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("bgcolor", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    let data = ev.dataTransfer.getData("bgcolor");
    ev.target.style.backgroundColor = data;
}

function getMatchingWaitingRoomID() {
    let id = 1; //Id niet kunnen ophalen.
    let url = 'https://localhost:44317/api/Games/' + id;

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}
getMatchingWaitingRoomID();

function getStatus() {
    let id = 1; //Id niet kunnen ophalen.
    let url = 'https://localhost:44317/api/Games/' + id + '/status';

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}

getStatus();

function doGuess() {
    let id = 1; //Id niet kunnen ophalen.
    let round = 1; //Round niet kunnen ophalen.
    let url = 'https://localhost:44317/api/Games/' + id + '/canguess/forround/' + round;

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}

doGuess();

function postGuess() {
    let id = 1; //Id niet kunnen ophalen.
    let url = 'https://localhost:44317/api/Games/' + id + '/guess';

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(id),
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 201) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}
postGuess();