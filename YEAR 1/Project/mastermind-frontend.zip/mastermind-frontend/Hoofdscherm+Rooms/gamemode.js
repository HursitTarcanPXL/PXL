let sliderIn = 1;
showSlides(sliderIn);

function nextSlide(n) {
    showSlides(sliderIn += n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("slider");
    if (n > slides.length) {sliderIn = 1}
    if (n < 1) {sliderIn = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[sliderIn-1].style.display = "block";
}