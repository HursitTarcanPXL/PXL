let loginButton = document.getElementById('login-button');
loginButton.addEventListener("click", showAlert);

function showAlert() {
    let url = 'https://localhost:44317/api/Authentication/token' ;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let token = {email: email, password : password};

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(token),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();

            } else {
                throw `error with status ${response.status}`;
            }
        }).then((answer) => {
            sessionStorage.setItem("token", answer.token);
            window.location.replace("gamemode.html");
        });
}

