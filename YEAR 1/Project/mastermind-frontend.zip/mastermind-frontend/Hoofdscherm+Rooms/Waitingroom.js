function clearWaitingRooms() {
    let table = document.getElementById('waiting-rooms');
    for (let i = table.rows.length - 1; i > 0; i--) {
        table.deleteRow(i);
    }
}

function showWaitingRooms() {
    let url = 'https://localhost:44317/api/WaitingRooms' ;
    let table = document.getElementById("waiting-rooms");

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
        .then((rooms) => {
            for(let room of rooms) {
                let row = document.createElement('tr');
                let namecell = document.createElement("td");
                let players = document.createElement('td');
                let playButton = document.createElement('button');
                namecell.textContent = room.name;
                players.textContent = room.users.length;
                playButton.value = room.id;
                row.appendChild(namecell);
                row.appendChild(players);
                row.appendChild(playButton);
                table.appendChild(row);
            }
        });
}

setInterval(function() {clearWaitingRooms(); showWaitingRooms();}, 5000);

let createButton = document.getElementById('create-button');
createButton.addEventListener("click", addWaitingRoom);


function addWaitingRoom() {
    let url = 'https://localhost:44317/api/WaitingRooms';
    let newRoom = document.getElementById("nameNewRoom").value;
    let data = {
        "name": newRoom,
        "gameSettings": {
            "codeLength": 4,
            "amountOfColors": 8,
            "duplicateColorsAllowed": false,
            "maximumAmountOfGuesses": 10,
            "amountOfRounds": 1,
            "mode": 1
        }
    };

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 201) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}

function getMatchingWaitingRoomID() {
    let url = 'https://localhost:44317/api/';

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}

getMatchingWaitingRoomID();

function joinWaitingRoom() {
    let urlDeel1 = 'https://localhost:44317/api/WaitingRooms/';
    let id = 1; //Ik geraak niet aan de room id, daardoor mislukt deze fetch.
    let url = urlDeel1 + id + '/join';

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(id),
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 201) {
                window.location.replace('Waitingroom.html');
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}
//joinWaitingRoom();

function joinRoom() {
    window.location.replace('Waitingroom.html');
}

let but = document.getElementsByTagName('button')[1];
but.addEventListener("click", joinRoom);
