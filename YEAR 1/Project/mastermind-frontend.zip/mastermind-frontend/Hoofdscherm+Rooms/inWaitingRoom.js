function showPlayersInRooms() {
    let url = 'https://localhost:44317/api/WaitingRooms' ;
    let table = document.getElementById("waiting-rooms");

    fetch(url,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
        .then((rooms) => {
            for(let room of rooms) {
                let row = document.createElement('tr');
                let namecell = document.createElement("td");
                namecell.textContent = room.users[0].nickName;
                row.appendChild(namecell);
                table.appendChild(row);
            }
        });
}

setInterval(function() {clearWaitingRooms(); showPlayersInRooms();}, 5000);

function clearWaitingRooms() {
    let table = document.getElementById('waiting-rooms');
    for (let i = table.rows.length - 1; i > 0; i--) {
        table.deleteRow(i);
    }
}

function leaveWaitingRoom() {
    let urlDeel1 = 'https://localhost:44317/api/WaitingRooms/';
    let id = 1; //Ik geraak niet aan de room id, daardoor mislukt deze fetch.
    let url = urlDeel1 + id + '/leave';

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(id),
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 201) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}
//leaveWaitingRoom();

function startGame() {
    let urlDeel1 = 'https://localhost:44317/api/Games';
    let id = 1; //Ik geraak niet aan de waitingroom info, daardoor mislukt deze fetch.
    let url = urlDeel1 + id + '/join';

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(id),
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 201) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
}

let game = document.getElementById('start-button');
game.addEventListener("click", startGame);