let submitButton = document.getElementById('submit-button');
submitButton.addEventListener("click", showAlert);

function showAlert() {
    let url = 'https://localhost:44317/api/Authentication/register' ;
    let nickname = document.getElementById("nickname").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let registration = {email: email, nickname : nickname, password : password};

    fetch(url,
        {
            method: "POST",
            body: JSON.stringify(registration),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (response.status == 200) {
                window.location.replace("login.html");
            } else {
                throw `error with status ${response.status}`;
            }
        });
}